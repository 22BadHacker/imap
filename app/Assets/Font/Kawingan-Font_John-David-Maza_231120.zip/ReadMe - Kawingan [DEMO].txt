Kawingan [DEMO FONT LICENSE]
Original download link: gum.co/kawingan

---------------------------------------

View the DEMO FONT End User License Agreement (EULA) on 
https://gumroad.com/johndavidmaza/p/eula-demo

Some characters and special features will not be presented in the file. Please get the full version for the optimal experience. Any use of the demo font are at your own risk.

---------------------------------------

Browse fonts @ gumroad.com/johndavidmaza